﻿DShowNET for .NET Framework 4.0 by ksasao <k.sasao@gmail.com> 
10 Mar 2012
--------------
Original version (.NET Framework 1.0) is here.

DirectShow.NET By NETMaster
http://www.codeproject.com/Articles/2615/DirectShow-NET

Licence: Public Domain